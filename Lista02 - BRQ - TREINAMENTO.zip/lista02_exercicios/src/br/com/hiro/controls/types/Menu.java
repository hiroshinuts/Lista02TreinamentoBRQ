package br.com.hiro.controls.types;

public enum Menu {
	
	CADASTRAR,
	ATUALIZAR,
	EXCLUIR,
	CONSULTAR,
	SAIR

}
