package br.com.hiro.principal;

import br.com.hiro.controls.ControleAluno;

public class Main {
	
	public static void main(String[] args) {
		
		
		ControleAluno c = new ControleAluno();
		c.menuAluno();
		
	}

}
